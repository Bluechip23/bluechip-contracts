# BlueChip Creator Subsriptions Smart Contract

## Fully Decentralized Subscription Model
